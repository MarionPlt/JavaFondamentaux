public class ConsoleColors {
    // Reset
    public static final String RESET = "\033[0m";

    // Red
    public static final String RED = "\033[0;31m";
    
    // Bold
    public static final String BOLD = "\033[0;1m";
}